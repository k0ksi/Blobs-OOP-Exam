﻿namespace Blobs.Interfaces
{
    public interface IInputController
    {
        string ReadInput();
    }
}