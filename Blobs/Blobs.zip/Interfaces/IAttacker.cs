﻿namespace Blobs.Interfaces
{
    public interface IAttacker
    {
        int AttackDamage { get; set; } 
    }
}