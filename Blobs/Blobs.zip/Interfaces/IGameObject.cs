﻿namespace Blobs.Interfaces
{
    public interface IGameObject
    {
        string Name { get; set; }
    }
}