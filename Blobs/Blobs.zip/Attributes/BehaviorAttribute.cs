﻿using System;

namespace Blobs.Attributes
{
    [AttributeUsage(AttributeTargets.Class)]
    public class BehaviorAttribute : Attribute
    {
    }
}